// IDENTIFIERS_USED=armAsDcMotor,gamepad1

/**
 * This OpMode offers POV (point-of-view) style
 * TeleOp control for a direct drive robot.
 *
 * In this POV mode, the left joystick (up and down) moves the
 * robot forward and back, and the right joystick (left and right)
 * spins the robot left (counterclockwise) and right (clockwise).
 */
function runOpMode() {
  // You will have to determine which motor to reverse for your robot.
  // In this example, the right motor was reversed so that positive
  // applied power makes it move the robot in the forward direction.
  armAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      armAsDcMotor.setPower(gamepad1.getRightStickY() / 1 + gamepad1.getRightStickX() / 1);
      telemetry.addNumericData('Arm Power', armAsDcMotor.getPower());
      telemetry.update();
    }
  }
}
