// IDENTIFIERS_USED=gamepad1,horizontalSliderAsDcMotor,htSensorAsTouchSensor,intakeWristAsServo,rightHookAsDcMotor

var normalPosition;

/**
 * This OpMode offers Tank Drive style TeleOp control for a direct drive robot.
 *
 * In this Tank Drive mode, the left and right joysticks (up
 * and down) drive the left and right motors, respectively.
 */
function runOpMode() {
  normalPosition = 0.45;
  // You will have to determine which motor to reverse for your robot.
  // In this example, the right motor was reversed so that positive
  // applied power makes it move the robot in the forward direction.
  rightHookAsDcMotor.setDirection("REVERSE");
  intakeWristAsServo.setPosition(normalPosition);
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (htSensorAsTouchSensor.getIsPressed() && gamepad1.getLeftStickX() > 0) {
        horizontalSliderAsDcMotor.setPower(0);
      } else {
        horizontalSliderAsDcMotor.setPower(gamepad1.getLeftStickX() / 2);
      }
      telemetry.addNumericData('Left Pow', horizontalSliderAsDcMotor.getPower());
      telemetry.update();
    }
  }
}
