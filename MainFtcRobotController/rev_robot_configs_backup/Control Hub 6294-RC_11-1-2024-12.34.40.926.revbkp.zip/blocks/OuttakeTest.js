// IDENTIFIERS_USED=leftServoAsServo,rightServoAsServo

var ServoPosition, ServoSpeed;

/**
 * This sample OpMode shows how to operate a
 * conventional servo at a smooth, controlled rate.
 */
function runOpMode() {
  ServoPosition = 0.9;
  ServoSpeed = 0.1;
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    leftServoAsServo.setDirection("REVERSE");
    rightServoAsServo.setPosition(ServoPosition);
    leftServoAsServo.setPosition(ServoPosition);
    telemetry.addNumericData('Servo', ServoPosition);
    telemetry.update();
    linearOpMode.sleep(20);
  }
}
