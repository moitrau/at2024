// IDENTIFIERS_USED=gamepad1,intakeLWAsServo,intakeRWAsServo,intakeWristAsServo

var normalPosition, consumePosition, intakePosition;

/**
 * This sample OpMode shows how to operate a
 * conventional servo at a smooth, controlled rate.
 */
function runOpMode() {
  consumePosition = 0.6;
  normalPosition = 0.45;
  intakePosition = 0.3;
  intakeWristAsServo.setPosition(normalPosition);
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getY()) {
      intakeWristAsServo.setPosition(normalPosition);
    }
    if (gamepad1.getX()) {
      intakeWristAsServo.setPosition(intakePosition);
    }
    if (gamepad1.getDpadUp()) {
      intakeWristAsServo.setPosition(consumePosition);
    }
    if (gamepad1.getA()) {
      intakeLWAsServo.setDirection("REVERSE");
      intakeLWAsServo.setPosition(0.9);
      intakeRWAsServo.setPosition(0.9);
    }
    if (gamepad1.getB()) {
      intakeLWAsServo.setPosition(0.5);
      intakeRWAsServo.setPosition(0.5);
    }
    telemetry.addNumericData('Servo', intakeWristAsServo.getPosition());
    telemetry.update();
  }
}
