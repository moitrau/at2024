// IDENTIFIERS_USED=limelightAsLimelight3A

var status2, result, botpose, captureLatency, targetingLatency, fiducialResults, fiducialResult, colorResults, colorResult;

/**
 * This OpMode illustrates how to use the Limelight3A Vision Sensor.
 *
 * See https://limelightvision.io/
 *
 * Notes on configuration:
 *
 * The device presents itself, when plugged into a USB
 * port on a Control Hub as an ethernet interface. A DHCP
 * server running on the Limelight automatically assigns the
 * Control Hub an ip address for the new ethernet interface.
 *
 * Since the Limelight is plugged into a USB port, it will be
 * listed on the top level configuration activity along with
 * the Control Hub Portal and other USB devices such as webcams.
 * Typically serial numbers are displayed below the device's names.
 * In the case of the Limelight device, the Control Hub's assigned ip
 * address for that ethernet interface is used as the "serial number".
 *
 * Tapping the Limelight's name, transitions to a new screen where
 * the user can rename the Limelight and specify the Limelight's
 * ip address. Users should take care not to confuse the ip
 * address of the Limelight itself, which can be configured
 * through the Limelight settings page via a web browser, and
 * the ip address the Limelight device assigned the Control
 * Hub and which is displayed in small text below the name
 * of the Limelight on the top level configuration screen.
 */
function runOpMode() {
  telemetry.setMsTransmissionInterval(11);
  limelightAsLimelight3A.pipelineSwitch(0);
  limelightAsLimelight3A.start();
  telemetryAddTextData('>', 'Robot Ready.  Press Play.');
  telemetry.update();
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    status2 = limelightAsLimelight3A.getStatus();
    telemetryAddTextData('Name', startBlockExecution("LLStatus.Name") ? endBlockExecution(getObjectViaJson(miscAccess,status2).name) : 0);
    telemetryAddTextData('LL', ['Temp: ',miscAccess.formatNumber(startBlockExecution("LLStatus.Temp") ? endBlockExecution(getObjectViaJson(miscAccess,status2).temp) : 0, 1),'C, CPU: ',miscAccess.formatNumber(startBlockExecution("LLStatus.Cpu") ? endBlockExecution(getObjectViaJson(miscAccess,status2).cpu) : 0, 1),'%, FPS: ',Math.round(startBlockExecution("LLStatus.Fps") ? endBlockExecution(getObjectViaJson(miscAccess,status2).fps) : 0)].join(''));
    telemetryAddTextData('Pipeline', ['Index: ',startBlockExecution("LLStatus.PipelineIndex") ? endBlockExecution(getObjectViaJson(miscAccess,status2).pipelineIndex) : 0,', Type: ',startBlockExecution("LLStatus.PipelineType") ? endBlockExecution(getObjectViaJson(miscAccess,status2).pipelineType) : 0].join(''));
    result = limelightAsLimelight3A.getLatestResult();
    if (result != null) {
      botpose = startBlockExecution("LLResult.Botpose") ? endBlockExecution(getObjectViaJson(miscAccess,result).Botpose) : 0;
      captureLatency = startBlockExecution("LLResult.CaptureLatency") ? endBlockExecution(getObjectViaJson(miscAccess,result).CaptureLatency) : 0;
      targetingLatency = startBlockExecution("LLResult.TargetingLatency") ? endBlockExecution(getObjectViaJson(miscAccess,result).TargetingLatency) : 0;
      telemetryAddTextData('PythonOutput', (startBlockExecution("LLResult.PythonOutput") ? endBlockExecution(getObjectViaJson(miscAccess,result).PythonOutput) : 0).join(','));
      telemetry.addNumericData('tx', startBlockExecution("LLResult.Tx") ? endBlockExecution(getObjectViaJson(miscAccess,result).Tx) : 0);
      telemetry.addNumericData('txnc', startBlockExecution("LLResult.TxNC") ? endBlockExecution(getObjectViaJson(miscAccess,result).TxNC) : 0);
      telemetry.addNumericData('ty', startBlockExecution("LLResult.Ty") ? endBlockExecution(getObjectViaJson(miscAccess,result).Ty) : 0);
      telemetry.addNumericData('tync', startBlockExecution("LLResult.TyNC") ? endBlockExecution(getObjectViaJson(miscAccess,result).TyNC) : 0);
      telemetryAddTextData('Botpose', llResultAccess.pose3DToText(JSON.stringify(botpose)));
      telemetry.addNumericData('LL Latency', captureLatency + targetingLatency);
      fiducialResults = startBlockExecution("LLResult.FiducialResults") ? endBlockExecution(getObjectViaJson(miscAccess,result).FiducialResults) : 0;
      for (var fiducialResult_index in fiducialResults) {
        fiducialResult = fiducialResults[fiducialResult_index];
        telemetryAddTextData('Fiducial', ['ID: ',startBlockExecution("FiducialResult.FiducialId") ? endBlockExecution(fiducialResult.fiducialId) : 0,', Family: ',startBlockExecution("FiducialResult.Family") ? endBlockExecution(fiducialResult.family) : 0,', X: ',miscAccess.formatNumber(startBlockExecution("FiducialResult.TargetXDegrees") ? endBlockExecution(fiducialResult.targetXDegrees) : 0, 2),', Y: ',miscAccess.formatNumber(startBlockExecution("FiducialResult.TargetYDegrees") ? endBlockExecution(fiducialResult.targetYDegrees) : 0, 2)].join(''));
        colorResults = startBlockExecution("LLResult.ColorResults") ? endBlockExecution(getObjectViaJson(miscAccess,result).ColorResults) : 0;
        for (var colorResult_index in colorResults) {
          colorResult = colorResults[colorResult_index];
          telemetryAddTextData('Color', ['X: ',miscAccess.formatNumber(startBlockExecution("ColorResult.TargetXDegrees") ? endBlockExecution(colorResult.targetXDegrees) : 0, 2),', Y: ',miscAccess.formatNumber(startBlockExecution("ColorResult.TargetYDegrees") ? endBlockExecution(colorResult.targetYDegrees) : 0, 2)].join(''));
        }
      }
    } else {
      telemetryAddTextData('Limelight', 'No data available');
    }
    telemetry.update();
  }
  limelightAsLimelight3A.stop();
}
