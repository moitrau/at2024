// IDENTIFIERS_USED=clawArmAsServo,clawAsServo,clawWristAsServo,gamepad1,intakeWristAsServo

var intakeWrist, claw, clawWrist, clawArm;

/**
 * This sample OpMode shows how to operate a
 * conventional servo at a smooth, controlled rate.
 */
function runOpMode() {
  intakeWrist = 0.6;
  claw = 0.45;
  clawWrist = 0.6;
  clawArm = 0.38;
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getDpadUp()) {
      clawArm = clawArm + 0.001;
      clawArmAsServo.setPosition(clawArm);
    }
    if (gamepad1.getDpadDown()) {
      clawArm = clawArm - 0.001;
      clawArmAsServo.setPosition(clawArm);
    }
    if (gamepad1.getDpadRight()) {
      clawWrist = clawWrist + 0.001;
      clawWristAsServo.setPosition(clawWrist);
    }
    if (gamepad1.getDpadLeft()) {
      clawWrist = clawWrist - 0.001;
      clawWristAsServo.setPosition(clawWrist);
    }
    if (gamepad1.getA()) {
      claw = claw + 0.01;
      clawAsServo.setPosition(claw);
    }
    if (gamepad1.getB()) {
      claw = claw - 0.01;
      clawAsServo.setPosition(claw);
    }
    if (gamepad1.getX()) {
      intakeWrist = intakeWrist + 0.001;
      intakeWristAsServo.setPosition(intakeWrist);
    }
    if (gamepad1.getY()) {
      intakeWrist = intakeWrist - 0.001;
      intakeWristAsServo.setPosition(intakeWrist);
    }
    telemetry.addNumericData('claw', clawAsServo.getPosition());
    telemetry.addNumericData('clawArm', clawArmAsServo.getPosition());
    telemetry.addNumericData('clawWrist', clawWristAsServo.getPosition());
    telemetry.addNumericData('intakeWrist', intakeWristAsServo.getPosition());
    telemetry.update();
  }
}
