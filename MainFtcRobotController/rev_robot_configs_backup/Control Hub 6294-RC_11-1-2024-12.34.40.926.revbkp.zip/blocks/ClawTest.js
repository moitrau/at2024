// IDENTIFIERS_USED=clawArmAsServo,clawAsServo,clawWristAsServo,gamepad1

var clawOpenPosition, clawClosePosition, clawWristInPosition, clawWristOutPosition, clawArmUpPosition, clawArmDownPostion;

/**
 * This sample OpMode shows how to operate a
 * conventional servo at a smooth, controlled rate.
 */
function runOpMode() {
  clawOpenPosition = 0.45;
  clawClosePosition = 0.7;
  clawWristInPosition = 0.6;
  clawWristOutPosition = 0;
  clawArmUpPosition = 0.18;
  clawArmDownPostion = 0.7;
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getDpadDown()) {
      clawArmAsServo.setPosition(clawArmDownPostion);
    }
    if (gamepad1.getDpadUp()) {
      clawArmAsServo.setPosition(clawArmUpPosition);
    }
    if (gamepad1.getDpadLeft()) {
      clawWristAsServo.setPosition(clawWristInPosition);
    }
    if (gamepad1.getDpadRight()) {
      clawWristAsServo.setPosition(clawWristOutPosition);
    }
    if (gamepad1.getA()) {
      clawAsServo.setPosition(clawOpenPosition);
    }
    if (gamepad1.getB()) {
      clawAsServo.setPosition(clawClosePosition);
    }
    telemetry.addNumericData('claw', clawAsServo.getPosition());
    telemetry.addNumericData('clawArm', clawArmAsServo.getPosition());
    telemetry.addNumericData('clawWrist', clawWristAsServo.getPosition());
    telemetry.update();
  }
}
