// IDENTIFIERS_USED=gamepad2,leftHookAsDcMotor,rightHookAsDcMotor

/**
 * This OpMode offers Tank Drive style TeleOp control for a direct drive robot.
 *
 * In this Tank Drive mode, the left and right joysticks (up
 * and down) drive the left and right motors, respectively.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad2.getRightBumper()) {
        leftHookAsDcMotor.setPower(1);
        rightHookAsDcMotor.setPower(1);
      } else {
        leftHookAsDcMotor.setPower(0);
        rightHookAsDcMotor.setPower(0);
      }
      if (gamepad2.getLeftBumper()) {
        leftHookAsDcMotor.setPower(-1);
        rightHookAsDcMotor.setPower(-1);
      } else {
        leftHookAsDcMotor.setPower(0);
        rightHookAsDcMotor.setPower(0);
      }
      telemetry.addNumericData('Left Pow', leftHookAsDcMotor.getPower());
      telemetry.addNumericData('Right Pow', rightHookAsDcMotor.getPower());
      telemetry.update();
    }
  }
}
