// IDENTIFIERS_USED=frontLeftAsDcMotor,frontRightAsDcMotor,gamepad1,rearLeftAsDcMotor,rearRightAsDcMotor

/**
 * This OpMode offers POV (point-of-view) style
 * TeleOp control for a direct drive robot.
 *
 * In this POV mode, the left joystick (up and down) moves the
 * robot forward and back, and the right joystick (left and right)
 * spins the robot left (counterclockwise) and right (clockwise).
 */
function runOpMode() {
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      // The Y axis of a joystick ranges from -1 in its topmost position
      // to +1 in its bottommost position. We negate this value so that
      // the topmost position corresponds to maximum forward power.
      frontLeftAsDcMotor.setDualPower((-gamepad1.getLeftStickY() + gamepad1.getRightStickX()) / 2, frontRightAsDcMotor, (-gamepad1.getLeftStickY() - gamepad1.getRightStickX()) / 2);
      // The Y axis of a joystick ranges from -1 in its topmost position
      // to +1 in its bottommost position. We negate this value so that
      // the topmost position corresponds to maximum forward power.
      rearLeftAsDcMotor.setDualPower((-gamepad1.getLeftStickY() + gamepad1.getRightStickX()) / 2, rearRightAsDcMotor, (-gamepad1.getLeftStickY() - gamepad1.getRightStickX()) / 2);
      telemetry.addNumericData('Front Left Pow', frontLeftAsDcMotor.getPower());
      telemetry.addNumericData('Front Right Pow', frontRightAsDcMotor.getPower());
      telemetry.addNumericData('Rear Right Pow', rearRightAsDcMotor.getPower());
      telemetry.addNumericData('Rear Left Pow', rearLeftAsDcMotor.getPower());
      telemetry.update();
    }
  }
}
