// IDENTIFIERS_USED=frontLeftAsDcMotor,frontRightAsDcMotor,imuAsIMU

var maxDriveSpeed, distance, heading, maxTurnSpeed, holdTime, desiredHeading, proportionalGain, drive, turn, straight, headingError, holdTimer, orientation, targetHeading, steeringCorrection, driveSpeed, turnSpeed, moveCounts, P_DRIVE_GAIN, leftSpeed, leftTarget, rightSpeed, rightTarget, COUNTS_PER_INCH, HEADING_THRESHOLD, max, P_TURN_GAIN, orientationOnRobot, COUNTS_PER_MOTOR_REV, DRIVE_GEAR_REDUCTION, WHEEL_DIAMETER_INCHES, DRIVE_SPEED, TURN_SPEED;

/**
 * This OpMode illustrates the concept of driving an autonomous
 * path based on gyro (IMU) heading and encoder counts.
 *
 * The path to be followed by the robot is built from a series of
 * drive, turn or pause steps. Each step on the path is defined by a
 * single function call, and these can be strung together in any order.
 *
 * This OpMode requires that you have encoders on the drive
 * motors, otherwise you should use RobotAutoDriveByTime.
 *
 * This OpMode uses the Universal IMU interface so it will work
 * with either the BNO055 or BHI260 IMU. To run as written,
 * the Control/Expansion hub should be mounted horizontally
 * on a flat part of the robot chassis. The REV Logo should be
 * facing up, and the USB port should be facing forward. If this
 * is not the configuration of your REV Control Hub, then this
 * OpMode should be modified to reflect the correct orientation.
 *
 * This sample requires that the drive motors have been
 * configured with names: left_drive and right_drive.
 * It also requires that a positive power command moves both
 * motors forward, and causes the encoders to count up. Please
 * verify that both of your motors move the robot forward on
 * the first move. If not, make the required correction in
 * runOpMode to set the FORWARD/REVERSE option for each motor.
 *
 * This OpMode uses RUN_TO_POSITION mode for driving straight,
 * and RUN_USING_ENCODER mode for turning and holding.
 *
 * All angles are referenced to the coordinate-frame that is set
 * whenever resetHeading is called. In this sample, the heading
 * is reset when the Start button is touched on the Driver
 * Station. Note: It would be possible to reset the heading
 * after each move, but this would accumulate steering errors.
 *
 * The angle of movement/rotation is assumed to be a
 * standardized rotation around the robot Z axis, which
 * means that a Positive rotation is Counter Clockwise,
 * looking down on the field. This is consistent with the
 * FTC field coordinate conventions set out in the document:
 * https://ftc-docs.firstinspires.org/field-coordinate-system
 *
 * To reach, or maintain a required heading, this OpMode
 * implements a basic Proportional Controller where:
 * - Steering power = Heading Error * Proportional Gain.
 * - Heading Error is calculated by taking the difference
 * between the desired heading and the actual heading, and then
 * normalizing it by converting it to a value in the +/- 180 degree range.
 * - Proportional Gain is a constant that you choose
 * to set the "strength" of the steering response.
 */
function runOpMode() {
  initializeVariables();
  frontLeftAsDcMotor.setDirection("REVERSE");
  frontRightAsDcMotor.setDirection("FORWARD");
  orientationOnRobot = revHubOrientationOnRobotAccess.create1("UP", "FORWARD");
  imuAsIMU.initialize(imuParametersAccess.create(orientationOnRobot));
  frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  frontLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", frontRightAsDcMotor, "BRAKE");
  while (linearOpMode.opModeInInit()) {
    telemetryAddTextData('>', 'Robot Heading = ' + String(miscAccess.formatNumber_withWidth(getHeading(), 4, 0)));
    telemetry.update();
  }
  if (linearOpMode.opModeIsActive()) {
    frontLeftAsDcMotor.setDualMode("RUN_USING_ENCODER", frontRightAsDcMotor, "RUN_USING_ENCODER");
    imuAsIMU.resetYaw();
    driveStraight(DRIVE_SPEED, 24, 0);
    turnToHeading(TURN_SPEED, -45);
    holdHeading(TURN_SPEED, -45, 0.5);
    driveStraight(DRIVE_SPEED, 17, -45);
    turnToHeading(TURN_SPEED, 45);
    holdHeading(TURN_SPEED, 45, 0.5);
    driveStraight(DRIVE_SPEED, 17, 45);
    turnToHeading(TURN_SPEED, 0);
    holdHeading(TURN_SPEED, 0, 1);
    driveStraight(DRIVE_SPEED, -48, 0);
    telemetryAddTextData('Path', 'Complete');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
}

/**
 * Initialize the variables.
 */
function initializeVariables() {
  headingError = 0;
  targetHeading = 0;
  driveSpeed = 0;
  turnSpeed = 0;
  leftSpeed = 0;
  rightSpeed = 0;
  leftTarget = 0;
  rightTarget = 0;
  // eg: GoBILDA 312 RPM Yellow Jacket
  COUNTS_PER_MOTOR_REV = 537.7;
  // No External Gearing.
  DRIVE_GEAR_REDUCTION = 1;
  // For figuring circumference
  WHEEL_DIAMETER_INCHES = 4;
  COUNTS_PER_INCH = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION) / (WHEEL_DIAMETER_INCHES * Math.PI);
  // Max driving speed for better distance accuracy.
  DRIVE_SPEED = 0.4;
  // Max turn speed to limit turn rate.
  TURN_SPEED = 0.2;
  // How close must the heading get to the target before moving to next step.
  // Requiring more accuracy (a smaller number) will often
  // make the turn take longer to get into the final position.
  HEADING_THRESHOLD = 1;
  // Larger is more responsive, but also less stable.
  P_TURN_GAIN = 0.02;
  // Larger is more responsive, but also less stable.
  P_DRIVE_GAIN = 0.03;
}

/**
 * Drive in a straight line, on a fixed compass
 * heading (angle), based on encoder counts.
 * Move will stop if either of these conditions occur:
 * 1) Move gets to the desired position.
 * 2) Driver stops the OpMode running.
 */
function driveStraight(maxDriveSpeed, distance, heading) {
  if (linearOpMode.opModeIsActive()) {
    moveCounts = Math.floor(distance * COUNTS_PER_INCH);
    leftTarget = frontLeftAsDcMotor.getCurrentPosition() + moveCounts;
    rightTarget = frontRightAsDcMotor.getCurrentPosition() + moveCounts;
    frontLeftAsDcMotor.setDualTargetPosition(leftTarget, frontRightAsDcMotor, rightTarget);
    frontLeftAsDcMotor.setDualMode("RUN_TO_POSITION", frontRightAsDcMotor, "RUN_TO_POSITION");
    maxDriveSpeed = Math.abs(maxDriveSpeed);
    moveRobot(maxDriveSpeed, 0);
    while (linearOpMode.opModeIsActive() && frontLeftAsDcMotor.isBusy() && frontRightAsDcMotor.isBusy()) {
      turnSpeed = getSteeringCorrection(heading, P_DRIVE_GAIN);
      if (distance < 0) {
        turnSpeed = -turnSpeed;
      }
      moveRobot(driveSpeed, turnSpeed);
      sendTelemetry(true);
    }
    moveRobot(0, 0);
    frontLeftAsDcMotor.setDualMode("RUN_USING_ENCODER", frontRightAsDcMotor, "RUN_USING_ENCODER");
  }
}

/**
 * Spin on the central axis to point in a new direction.
 * Move will stop if either of these conditions occur:
 * 1) Move gets to the heading (angle).
 * 2) Driver stops the OpMode running.
 */
function turnToHeading(maxTurnSpeed, heading) {
  steeringCorrection = getSteeringCorrection(heading, P_DRIVE_GAIN);
  while (linearOpMode.opModeIsActive() && Math.abs(headingError) > HEADING_THRESHOLD) {
    turnSpeed = getSteeringCorrection(heading, P_TURN_GAIN);
    turnSpeed = rangeAccess.clip(turnSpeed, -maxTurnSpeed, maxTurnSpeed);
    moveRobot(0, turnSpeed);
    sendTelemetry(false);
  }
  moveRobot(0, 0);
}

/**
 * Obtain & hold a heading for a finite amount of time
 * Move will stop once the requested time has elapsed
 * This function is useful for giving the robot a
 * moment to stabilize its heading between movements.
 */
function holdHeading(maxTurnSpeed, heading, holdTime) {
  holdTimer = elapsedTimeAccess.create();
  elapsedTimeAccess.reset(holdTimer);
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getSeconds(holdTimer) < holdTime) {
    turnSpeed = getSteeringCorrection(heading, P_TURN_GAIN);
    turnSpeed = rangeAccess.clip(turnSpeed, -maxTurnSpeed, maxTurnSpeed);
    moveRobot(0, turnSpeed);
    sendTelemetry(false);
  }
  moveRobot(0, 0);
}

/**
 * Use a Proportional Controller to determine
 * how much steering correction is required.
 */
function getSteeringCorrection(desiredHeading, proportionalGain) {
  targetHeading = desiredHeading;
  headingError = targetHeading - getHeading();
  while (headingError > 180) {
    headingError = headingError - 360;
  }
  while (headingError <= -180) {
    headingError = headingError + 360;
  }
  return rangeAccess.clip(headingError * proportionalGain, -1, 1);
}

/**
 * Takes separate drive (fwd/rev) and turn (right/left)
 * requests, combines them, and applies the appropriate
 * speed commands to the left and right wheel motors.
 */
function moveRobot(drive, turn) {
  driveSpeed = drive;
  turnSpeed = turn;
  leftSpeed = drive - turn;
  rightSpeed = drive + turn;
  max = Math.max(Math.abs(leftSpeed), Math.abs(rightSpeed));
  if (max > 1) {
    leftSpeed = leftSpeed / max;
    rightSpeed = rightSpeed / max;
  }
  frontLeftAsDcMotor.setDualPower(leftSpeed, frontRightAsDcMotor, rightSpeed);
}

/**
 * Display the various control parameters while driving.
 */
function sendTelemetry(straight) {
  if (straight) {
    telemetryAddTextData('Motion', 'Drive Straight');
    telemetryAddTextData('Target Pos L:R', [miscAccess.formatNumber_withWidth(leftTarget, 7, 0),':',miscAccess.formatNumber_withWidth(rightTarget, 7, 0)].join(''));
    telemetryAddTextData('Actual Pos L:R', [miscAccess.formatNumber_withWidth(frontLeftAsDcMotor.getCurrentPosition(), 7, 0),':',miscAccess.formatNumber_withWidth(frontRightAsDcMotor.getCurrentPosition(), 7, 0)].join(''));
  } else {
    telemetryAddTextData('Motion', 'Turning');
  }
  telemetryAddTextData('Heading- Target : Current', [miscAccess.formatNumber_withWidth(targetHeading, 5, 2),' : ',miscAccess.formatNumber_withWidth(getHeading(), 5, 0)].join(''));
  telemetryAddTextData('Error  : Steer Pwr', [miscAccess.formatNumber_withWidth(headingError, 5, 1),' : ',miscAccess.formatNumber_withWidth(turnSpeed, 5, 1)].join(''));
  telemetryAddTextData('Wheel Speeds L : R', [miscAccess.formatNumber_withWidth(leftSpeed, 5, 2),' : ',miscAccess.formatNumber_withWidth(rightSpeed, 5, 2)].join(''));
  telemetry.update();
}

/**
 * Read the robot heading directly from the IMU (in degrees).
 */
function getHeading() {
  orientation = imuAsIMU.getRobotYawPitchRollAngles();
  return yawPitchRollAnglesAccess.getYaw(orientation, "DEGREES");
}
