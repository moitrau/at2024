// IDENTIFIERS_USED=distanceSensorAsDistanceSensor

/**
 * This OpMode demonstrates the color and distance features of the REV sensor.
 */
function runOpMode() {
  telemetryAddTextData('Distance Example', 'Press start to continue...');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetry.addNumericData('Dist to tgt (cm)', distanceSensorAsDistanceSensor.getDistance("CM"));
      telemetry.update();
    }
  }
}
