// IDENTIFIERS_USED=gamepad2,leftHookAsDcMotor,rightHookAsDcMotor

/**
 * This OpMode offers Tank Drive style TeleOp control for a direct drive robot.
 *
 * In this Tank Drive mode, the left and right joysticks (up
 * and down) drive the left and right motors, respectively.
 */
function runOpMode() {
  rightHookAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      // The Y axis of a joystick ranges from -1 in its topmost position
      // to +1 in its bottommost position. We negate this value so that
      // the topmost position corresponds to maximum forward power.
      leftHookAsDcMotor.setDualPower(-gamepad2.getRightStickY(), rightHookAsDcMotor, -gamepad2.getLeftStickY());
      telemetry.addNumericData('Left Pow', leftHookAsDcMotor.getPower());
      telemetry.addNumericData('Right Pow', rightHookAsDcMotor.getPower());
      telemetry.update();
    }
  }
}
