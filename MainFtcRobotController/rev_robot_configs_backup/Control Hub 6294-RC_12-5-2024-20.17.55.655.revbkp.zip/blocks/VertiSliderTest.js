// IDENTIFIERS_USED=gamepad1,verticalSliderAsDcMotor,vtSensorAsTouchSensor

/**
 * This OpMode offers Tank Drive style TeleOp control for a direct drive robot.
 *
 * In this Tank Drive mode, the left and right joysticks (up
 * and down) drive the left and right motors, respectively.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      verticalSliderAsDcMotor.setDirection("REVERSE");
      if (vtSensorAsTouchSensor.getIsPressed() && gamepad1.getLeftStickY() >= 0) {
        verticalSliderAsDcMotor.setPower(0);
      } else {
        verticalSliderAsDcMotor.setPower(gamepad1.getLeftStickY() / 1);
      }
      telemetry.addNumericData('Left Pow', verticalSliderAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
  }
}
