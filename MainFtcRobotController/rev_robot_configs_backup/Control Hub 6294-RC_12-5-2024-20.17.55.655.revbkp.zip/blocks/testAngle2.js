// IDENTIFIERS_USED=gamepad1,imuAsIMU

var xRotation, yRotation, zRotation, hubRotation, orientationOnRobot, orientation, angularVelocity;

/**
 * This OpMode shows how to use the new universal IMU blocks.
 * These blocks may be used with the BNO055 IMU or the BHI260 IMU. It
 * assumes that an IMU is configured on the robot with the name "imu".
 *
 * The sample will display the current Yaw, Pitch and Roll of the robot.
 *
 * With the correct orientation parameters
 * selected, pitch/roll/yaw should act as follows:
 * * Pitch value should INCREASE as the robot is
 * tipped UP at the front. (Rotation about X)
 * * Roll value should INCREASE as the robot is
 * tipped UP at the left side. (Rotation about Y)
 * * Yaw value should INCREASE as the robot is
 * rotated Counter Clockwise. (Rotation about Z)
 *
 * The yaw can be reset (to zero) by pressing the Y
 * button on the gamepad (Triangle on a PS4 controller).
 *
 * This specific sample DOES NOT assume that the Hub is mounted on
 * one of the three orthogonal planes (X/Y, X/Z or Y/Z) OR that the
 * Hub has only been rotated in a range of 90 degree increments.
 *
 * Note: if your Hub is mounted Orthogonally (on a
 * orthogonal surface, angled at some multiple of 90 Degrees)
 * then you should use the simpler SensorHubIMUOrthogonal sample.
 *
 * But... If your Hub is mounted Non-Orthogonally, you must specify one
 * or more rotational angles that transform a "Default" Hub orientation
 * into your desired orientation. That is what is illustrated here.
 */
function runOpMode() {
  // Define how the Hub is mounted to the robot to
  // get the correct Yaw, Pitch, and Roll values.
  //
  // You can apply up to three axis rotations to orient
  // your Hub according to how it's mounted on the robot.
  //
  // The starting point for these rotations is the "Default" Hub orientation, which is:
  // 1) Hub laying flat on a horizontal surface, with the REV logo facing up.
  // 2) Rotated such that the USB ports are facing forward on the robot.
  //
  // The order that the rotations are performed matters, so
  // this sample shows doing them in the order X, Y, then Z.
  // For specifying non-orthogonal Hub mounting orientations, we
  // must temporarily use axes defined relative to the Hub itself,
  // instead of the usual Robot Coordinate System axes used for
  // the results the IMU gives us. In the starting orientation,
  // the Hub axes are aligned with the Robot Coordinate System:
  // * X Axis: Starting at center of Hub, pointing out towards I2C connectors
  // * Y Axis: Starting at center of Hub, pointing out towards USB connectors
  // * Z Axis: Starting at center of Hub, pointing up through the REV logo
  //
  // Positive rotation is defined by right-hand rule
  // with thumb pointing in +ve direction on axis.
  // Some examples.
  // ----------------------------------------------------------------------------------------------------------------------------------
  // Example A) Assume that the Hub is mounted on a sloped plate at
  // the back of the robot, with the USB ports coming out the top
  // of the Hub. The plate is tilted UP 60 degrees from horizontal.
  // To get the "Default" Hub into this configuration
  // you would just need a single rotation.
  // 1) Rotate the Hub +60 degrees around the X axis to tilt up the front edge.
  //  2) No rotation around the Y or Z axes.
  //  So the X,Y,Z rotations would be 60,0,0
  // ----------------------------------------------------------------------------------------------------------------------------------
  // Example B) Assume that the Hub is laying flat on the
  // chassis, but it has been twisted 30 degrees towards the
  // right front wheel to make the USB cable accessible.
  // To get the "Default" Hub into this configuration you would
  // just need a single rotation, but around a different axis.
  // 1) No rotation around the X or Y axes.
  // 2) Rotate the Hub -30 degrees (Clockwise) around the Z
  // axis, since a positive angle would be Counter Clockwise.
  // So the X,Y,Z rotations would be 0,0,-30
  // ----------------------------------------------------------------------------------------------------------------------------------
  // Example C) Assume that the Hub is mounted on a vertical
  // plate on the right side of the robot, with the REV logo
  // facing out, and the Hub rotated so that the USB ports are
  // facing down 30 degrees towards the back wheels of the robot.
  // To get the "Default" Hub into this configuration will require several rotations.
  // 1) Rotate the Hub +90 degrees around the X axis to get it standing
  // upright with the REV logo pointing backwards on the robot
  // 2) Next, rotate the Hub +90 around the Y axis to get it facing to the right.
  // 3) Finally rotate the Hub +120 degrees around the Z
  // axis to take the USB ports from vertical to sloping down
  // 30 degrees and facing towards the back of the robot.
  // So the X,Y,Z rotations would be 90,90,120
  // Enter the desired X rotation angle here.
  xRotation = 0;
  // Enter the desired Y rotation angle here.
  yRotation = 0;
  // Enter the desired Z rotation angle here.
  zRotation = 0;
  hubRotation = revHubOrientationOnRobotAccess.xyzOrientation(xRotation, yRotation, zRotation);
  orientationOnRobot = revHubOrientationOnRobotAccess.create2(hubRotation);
  imuAsIMU.initialize(imuParametersAccess.create(orientationOnRobot));
  while (!linearOpMode.isStopRequested()) {
    telemetryAddTextData('Hub orientation', ['X=',miscAccess.formatNumber(xRotation, 1),',  Y=',miscAccess.formatNumber(yRotation, 1),',  Z=',miscAccess.formatNumber(zRotation, 1)].join(''));
    telemetry.addLine('');
    if (gamepad1.getY()) {
      telemetryAddTextData('Yaw', 'Resetting');
      imuAsIMU.resetYaw();
    } else {
      telemetryAddTextData('Yaw', 'Press Y (triangle) on Gamepad to reset');
    }
    telemetry.addLine('');
    orientation = imuAsIMU.getRobotYawPitchRollAngles();
    angularVelocity = imuAsIMU.getRobotAngularVelocity("DEGREES");
    telemetryAddTextData('Yaw (Z)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getYaw(orientation, "DEGREES"), 2)) + ' Deg. (Heading)');
    telemetryAddTextData('Pitch (X)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getPitch(orientation, "DEGREES"), 2)) + ' Deg.');
    telemetryAddTextData('Roll (Y)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getRoll(orientation, "DEGREES"), 2)) + ' Deg.');
    telemetry.addLine('');
    telemetryAddTextData('Yaw (Z) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getZRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetryAddTextData('Pitch (X) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getXRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetryAddTextData('Roll (Y) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getYRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetry.update();
  }
}
