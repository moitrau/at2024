// IDENTIFIERS_USED=gamepad1,imuAsIMU

var orientationOnRobot, orientation2, angularVelocity;

/**
 * This OpMode shows how to use the new universal IMU
 * blocks with the REV 9-Axis IMU. It assumes that an
 * IMU is configured on the robot with the name "imu".
 *
 * The sample will display the current Yaw, Pitch and Roll of the robot.
 *
 * With the correct orientation parameters
 * selected, pitch/roll/yaw should act as follows:
 * * Pitch value should INCREASE as the robot is
 * tipped UP at the front. (Rotation about X)
 * * Roll value should INCREASE as the robot is
 * tipped UP at the left side. (Rotation about Y)
 * * Yaw value should INCREASE as the robot is
 * rotated Counter Clockwise. (Rotation about Z)
 *
 * The yaw can be reset (to zero) by pressing the Y
 * button on the gamepad (Triangle on a PS4 controller).
 *
 * This specific sample assumes that the IMU is mounted on one
 * of the three orthogonal planes (X/Y, X/Z or Y/Z) and that the
 * IMU has only been rotated in a range of 90 degree increments.
 *
 * Note: if your IMU is mounted on a surface angled at
 * some non-90 Degree multiple (like 30) look at the
 * alternative SensorRev9AxisIMUNonOrthogonal sample.
 *
 * This "Orthogonal" requirement means that:
 *
 * 1) The REV logo on the top of the IMU can
 * ONLY be pointing in one of six directions:
 *    FORWARD, BACKWARD, UP, DOWN, LEFT and RIGHT.
 *
 * 2) The I2C port can only be pointing in one of the same six directions:
 *    FORWARD, BACKWARD, UP, DOWN, LEFT and RIGHT.
 *
 * So, to fully define how your IMU is mounted to the robot, you must simply specify:
 * * LogoFacingDirection
 * * I2cPortFacingDirection
 *
 * Choose the two correct parameters to define how your IMU
 * is mounted and edit this OpMode to use those parameters.
 */
function runOpMode() {
  // Define how the IMU is mounted on the robot to
  // get the correct Yaw, Pitch and Roll values.
  //
  // Two input parameters are required to fully specify the Orientation.
  // The first parameter specifies the direction the REV logo on the IMU is pointing.
  // The second parameter specifies the direction the I2C port on the IMU is pointing.
  // All directions are relative to the robot, and
  // left/right is as-viewed from behind the robot.
  orientationOnRobot = rev9AxisImuOrientationOnRobotAccess.create1("LEFT", "UP");
  imuAsIMU.initialize(imuParametersAccess.create(orientationOnRobot));
  while (!linearOpMode.isStopRequested()) {
    if (gamepad1.getY()) {
      telemetryAddTextData('Yaw', 'Resetting');
      imuAsIMU.resetYaw();
    } else {
      telemetryAddTextData('Yaw', 'Press Y (triangle) on Gamepad to reset');
    }
    telemetry.addLine('');
    orientation2 = imuAsIMU.getRobotYawPitchRollAngles();
    angularVelocity = imuAsIMU.getRobotAngularVelocity("DEGREES");
    telemetryAddTextData('Yaw (Z)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getYaw(orientation2, "DEGREES"), 2)) + ' Deg. (Heading)');
    telemetryAddTextData('Pitch (X)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getPitch(orientation2, "DEGREES"), 2)) + ' Deg.');
    telemetryAddTextData('Roll (Y)', String(miscAccess.formatNumber(yawPitchRollAnglesAccess.getRoll(orientation2, "DEGREES"), 2)) + ' Deg.');
    telemetry.addLine('');
    telemetryAddTextData('Yaw (Z) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getZRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetryAddTextData('Pitch (X) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getXRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetryAddTextData('Roll (Y) velocity', String(miscAccess.formatNumber(angularVelocityAccess.getYRotationRate(angularVelocity), 2)) + ' Deg/Sec');
    telemetry.update();
  }
}
