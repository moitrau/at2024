/*
Copyright (c) 2024 Limelight Vision

All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted (subject to the limitations in the disclaimer below) provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

Neither the name of FIRST nor the names of its contributors may be used to
endorse or promote products derived from this software without specific prior
written permission.

NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.hardware.limelightvision.LLResult;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.LLStatus;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.hardware.LimelightHelpers.Results;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

import java.util.List;
import java.util.Arrays;

/*
 * This OpMode illustrates how to use the Limelight3A Vision Sensor.
 *
 * @see <a href="https://limelightvision.io/">Limelight</a>
 *
 * Notes on configuration:
 *
 *   The device presents itself, when plugged into a USB port on a Control Hub as an ethernet
 *   interface.  A DHCP server running on the Limelight automatically assigns the Control Hub an
 *   ip address for the new ethernet interface.
 *
 *   Since the Limelight is plugged into a USB port, it will be listed on the top level configuration
 *   activity along with the Control Hub Portal and other USB devices such as webcams.  Typically
 *   serial numbers are displayed below the device's names.  In the case of the Limelight device, the
 *   Control Hub's assigned ip address for that ethernet interface is used as the "serial number".
 *
 *   Tapping the Limelight's name, transitions to a new screen where the user can rename the Limelight
 *   and specify the Limelight's ip address.  Users should take care not to confuse the ip address of
 *   the Limelight itself, which can be configured through the Limelight settings page via a web browser,
 *   and the ip address the Limelight device assigned the Control Hub and which is displayed in small text
 *   below the name of the Limelight on the top level configuration screen.
 */

@TeleOp(name = "TestLimeLight3 (Blocks to Java)")
public class LimeLightTest3 extends LinearOpMode {

    private Limelight3A limelight;
    private DcMotor frontLeft;
    private DcMotor rearLeft;
    private DcMotor frontRight;
    private DcMotor rearRight;

    @Override
    public void runOpMode() throws InterruptedException
    {
        frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
        rearLeft = hardwareMap.get(DcMotor.class, "rearLeft");
        frontRight = hardwareMap.get(DcMotor.class, "frontRight");
        rearRight = hardwareMap.get(DcMotor.class, "rearRight");
    
        // Reverse one of the drive motors.
        frontLeft.setDirection(DcMotor.Direction.REVERSE);
        rearLeft.setDirection(DcMotor.Direction.REVERSE);
        
        limelight = hardwareMap.get(Limelight3A.class, "limelight");

        telemetry.setMsTransmissionInterval(11);

        limelight.pipelineSwitch(0);

        /*
         * Starts polling for data.  If you neglect to call start(), getLatestResult() will return null.
         */
        limelight.start();

        telemetry.addData(">", "Robot Ready.  Press Play.");
        telemetry.update();
        waitForStart();
        
        double[] xvalues = new double[20];
        double[] yvalues = new double[20];
        double[] yawvalues = new double[20];
        
        double xMean = 0;
        double yMean = 0;
        double yawMean = 0;
        
        int count = 0;
        
        while (opModeIsActive()) {
            LLStatus status = limelight.getStatus();
            frontLeft.setPower((-gamepad1.left_stick_y + gamepad1.right_stick_x) / 2);
            frontRight.setPower((-gamepad1.left_stick_y - gamepad1.right_stick_x) / 2);
            // The Y axis of a joystick ranges from -1 in its topmost position to +1 in its bottommost position.
            // We negate this value so that the topmost position corresponds to maximum forward power.
            rearLeft.setPower((-gamepad1.left_stick_y + gamepad1.right_stick_x) / 2);
            rearRight.setPower((-gamepad1.left_stick_y - gamepad1.right_stick_x) / 2);
            
            /**
            telemetry.addData("Name", "%s",
                    status.getName());
            telemetry.addData("LL", "Temp: %.1fC, CPU: %.1f%%, FPS: %d",
                    status.getTemp(), status.getCpu(),(int)status.getFps());
                    **/
            telemetry.addData("Pipeline", "Index: %d, Type: %s",
                    status.getPipelineIndex(), status.getPipelineType());

            LLResult result = limelight.getLatestResult();
            if (result != null) {
                // Access general information
                Pose3D botpose = result.getBotpose();
                double captureLatency = result.getCaptureLatency();
                double targetingLatency = result.getTargetingLatency();
                double parseLatency = result.getParseLatency();
                telemetry.addData("LL Latency", captureLatency + targetingLatency);
                telemetry.addData("Parse Latency", parseLatency);
                telemetry.addData("PythonOutput", java.util.Arrays.toString(result.getPythonOutput()));
                
                if (result.isValid()) {
                    telemetry.addData("tx", result.getTx());
                    telemetry.addData("ty", result.getTy());                    
                    telemetry.addData("txnc", result.getTxNC());
                    telemetry.addData("tync", result.getTyNC());

                    telemetry.addData("Botpose", botpose.toString());
                    telemetry.addData("Robotpose-X-Inch", botpose.getPosition().x * 39.3701);
                    telemetry.addData("RobotPose-Y-Inch", botpose.getPosition().y * 39.3701); 
                    //telemetry.addData("RobotPose-Y-Inch", botpose.getRotation().getYaw());
                    
                    //YawPitchRollAngles orientation = imu.getRobotYawPitchRollAngles();
                    YawPitchRollAngles orientation = botpose.getOrientation();
                    double robotYaw = orientation.getYaw();
                    
                    xvalues[count] = botpose.getPosition().x * 39.3701;
                    yvalues[count] = botpose.getPosition().y * 39.3701;
                    yawvalues[count] = robotYaw;
                    count++;
                    
                    // if (count > 18) {
                    // telemetry.addData("Count" ,  count);
                    // telemetry.addData("Test" ,  xvalues.length - 1);
                    // }
                    
                    if (count == xvalues.length - 1){
                        xMean = getFinalMean(xvalues);
                        yMean = getFinalMean(yvalues);
                        yawMean = getFinalMean(yawvalues);
                        //Thread.sleep(5000);
                        count = 0;
                        for (int i =0; i<=xvalues.length-1; i++) {
                            xvalues[i] = 0;
                            yvalues[i] = 0;
                            yawvalues[i] = 0;
                        }
                    }
                    
                    telemetry.addData("RobotPose-xMean" ,  xMean);
                    telemetry.addData("RobotPose-yMean" ,  yMean);
                    telemetry.addData("RobotPose-yawMean" ,  yawMean);
                    
                    /**
                    limelight.updateRobotOrientation(robotYaw);
                    if (result != null && result.isValid()) {
                        Pose3D botpose_mt2 = result.getBotpose_MT2();
                        if (botpose_mt2 != null) {
                            double x = botpose_mt2.getPosition().x;
                            double y = botpose_mt2.getPosition().y;
                            telemetry.addData("MT2 Location:", "(" + x * 39.3701 + ", " + y * 39.3701 + ")");
                        }
                    } 
                    
                    
                    // Access fiducial results
                    List<LLResultTypes.FiducialResult> fiducialResults = result.getFiducialResults();
                    for (LLResultTypes.FiducialResult fr : fiducialResults) {
                        telemetry.addData("Fiducial", "ID: %d, Family: %s, X: %.2f, Y: %.2f", fr.getFiducialId(), fr.getFamily(),fr.getTargetXDegrees(), fr.getTargetYDegrees());
                        telemetry.addData("RobotposeFieldSpace", fr.getRobotPoseFieldSpace() );
                        telemetry.addData("RobotPoseTargetSpace", fr.getRobotPoseTargetSpace());
                    }

                    // Access barcode results
                    List<LLResultTypes.BarcodeResult> barcodeResults = result.getBarcodeResults();
                    for (LLResultTypes.BarcodeResult br : barcodeResults) {
                        telemetry.addData("Barcode", "Data: %s", br.getData());
                    }

                    // Access classifier results
                    List<LLResultTypes.ClassifierResult> classifierResults = result.getClassifierResults();
                    for (LLResultTypes.ClassifierResult cr : classifierResults) {
                        telemetry.addData("Classifier", "Class: %s, Confidence: %.2f", cr.getClassName(), cr.getConfidence());
                    }

                    // Access detector results
                    List<LLResultTypes.DetectorResult> detectorResults = result.getDetectorResults();
                    for (LLResultTypes.DetectorResult dr : detectorResults) {
                        telemetry.addData("Detector", "Class: %s, Area: %.2f", dr.getClassName(), dr.getTargetArea());
                    }


                    // Access color results
                    List<LLResultTypes.ColorResult> colorResults = result.getColorResults();
                    for (LLResultTypes.ColorResult cr : colorResults) {
                        
                        //telemetry.addData("ColorOfSample", result. );
                        telemetry.addData("Color", "X: %.2f, Y: %.2f", cr.getTargetXDegrees(), cr.getTargetYDegrees());
                    }
                    **/
                }
            } else {
                telemetry.addData("Limelight", "No data available");
            }

            telemetry.update();
        }
        limelight.stop();
    }
    
        public static double getFinalMean (double[] array){
        double mean = calculateMean(array);
        double stdDev = calculateStandardDeviation(array, mean);

        int count = 0;
        double finalSum = 0;

        System.out.println("Mean: " + mean);
        System.out.println("Standard Deviation: " + stdDev);

        // Identify and print outliers (Z-Score > 2)
        System.out.println("Outliers:");
        for (double value : array) {
            double zScore = (value - mean) / stdDev;
            if (Math.abs(zScore) > 2) {  // Threshold of 2 standard deviations
                System.out.println(value + " (Z-Score: " + zScore + ")");
            }
            else {
                finalSum = finalSum + value;
                count++;
            }
        }
        return finalSum/count;
    }
    // Method to calculate the mean
    public static double calculateMean(double[] array) {
        double sum = 0.0;
        for (double num : array) {
            sum += num;
        }
        return sum / array.length;
    }

    // Method to calculate standard deviation
    public static double calculateStandardDeviation(double[] array, double mean) {
        double sum = 0.0;
        for (double num : array) {
            sum += Math.pow(num - mean, 2);
        }
        return Math.sqrt(sum / array.length);
    }
}
